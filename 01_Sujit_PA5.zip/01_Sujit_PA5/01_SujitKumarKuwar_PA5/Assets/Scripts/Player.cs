﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Player : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    public static int Coins=0;
    public Text Txt_Message;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
       Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);
        if(Coins>=4)
        {
            SceneManager.LoadScene(1);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag =="Obstacles")
        {
            SceneManager.LoadScene(2);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag=="Coin")
        {
            Coins ++;
            Txt_Message.text = "Coins Collected = " + Coins;
            Destroy(other.gameObject);

            
        }
    }
}

